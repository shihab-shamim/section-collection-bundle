const BtnOne = ({ isBtnOne, btnOneTextArea }) => {
    return isBtnOne && btnOneTextArea
}
export default BtnOne;