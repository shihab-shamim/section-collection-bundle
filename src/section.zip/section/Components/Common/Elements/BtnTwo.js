
const BtnTwo = ({ isBtnTwo, btnTwoTextArea }) => {
    return isBtnTwo && btnTwoTextArea;
}
export default BtnTwo;